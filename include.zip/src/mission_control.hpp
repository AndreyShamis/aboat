// mission_control.hpp
#pragma once

#include <Arduino.h>
#include <ArduinoJson.h>
#include "settings.h"
#include "lora_comm.hpp"
#include "LogInterface.hpp"
#include "PacketClasses.hpp"   // calcCRC16, PacketBase, PacketCommand, etc.
#include "PacketTransport.hpp" // LoRaPacket, packIntoLoRa, unpackLoRa

// -----------------------------------------------------------------------------
// MissionControl
//
// Handles sending commands and telemetry requests over LoRa,
// processes incoming fragments, ASA speed‐adaptation handshake, and ACKs.
// -----------------------------------------------------------------------------
class MissionControl : public LogInterface
{
public:
    MissionControl()
    {
        loraComm = new LoRaComm(MY_DEVICE_ID, this);
    }

    ~MissionControl()
    {
        delete loraComm;
    }

    // Initialize LoRaComm
    void begin()
    {
        Serial.println(F("[MC] Starting Mission Control..."));
        if (!loraComm->begin())
        {
            addLog(F("[MC] ERROR: Failed to initialize LoRaComm"));
        }
        else
        {
            addLog(F("[MC] LoRaComm initialized"));

            // запросить телеметрию:
            sendInfoRequest(CMD_TELEMETRY_FRAGMENT);

            // запросить “InfoEngine”:
            sendInfoRequest(CMD_INFO_ENGINE);

            // запросить общий статус:
            sendInfoRequest(CMD_STATUS);
        }
    }

    // Main loop: check for and handle incoming LoRa frames
    void loop()
    {
        uint8_t senderId;
        PacketBase hdr;
        uint8_t payloadBuf[MAX_LORA_PAYLOAD];

        if (loraComm->parseReceivedPacket(senderId, hdr, payloadBuf))
        {
            // Собираем сообщение в один String
            String msg = "[MC] Received packet: type=";
            msg += (char)hdr.packetType;
            msg += " id=";
            msg += hdr.packetId;
            msg += " from=";
            msg += senderId;
            addLog(msg);

            handlePacket(senderId, hdr, payloadBuf);
        }
    }

    // Send ASA (auto‐speed‐adaptation) request to boat
    void sendASARequest()
    {
        PacketCommand cmd{};
        cmd.packetType = CMD_REQUEST_ASA;
        cmd.packetId = nextPacketId++;
        cmd.payloadLen = 0;

        loraComm->sendPacket(cmd, BOAT_DEVICE_ID);
        addLog(F("📡 Sent ASA request to boat."));
    }

    // Send an arbitrary command string (e.g. “M:120”)
    void sendCommandString(const String &cmdStr)
    {
        if (cmdStr == "ASA")
        {
            sendASARequest();
            return;
        }

        PacketCommand cmd{};
        cmd.packetType = CMD_COMMAND_STRING;
        cmd.packetId = nextPacketId++;
        cmd.payloadLen = cmdStr.length();
        memcpy(reinterpret_cast<uint8_t *>(&cmd) + sizeof(PacketBase),
               cmdStr.c_str(),
               cmd.payloadLen);

        loraComm->sendPacket(cmd, BOAT_DEVICE_ID);
        addLog(String("[MC] Sent command string: ") + cmdStr);
    }

    // Log sink (override)
    void addLog(const String &msg) override
    {
        Serial.println(msg);
    }

private:
    LoRaComm *loraComm;
    uint8_t nextPacketId = 0;

    // Handle incoming PacketBase + payloadBuf
    void handlePacket(uint8_t sender,
                      const PacketBase &hdr,
                      const uint8_t *buf)
    {
        switch (hdr.packetType)
        {
        case CMD_ACK:
        {
            uint16_t ackFor = atoi(reinterpret_cast<const char *>(buf));
            addLog(String("[MC] ACK for packet ID: ") + ackFor);
            break;
        }

        case CMD_TELEMETRY_FRAGMENT:
        {
            String fragment(reinterpret_cast<const char *>(buf), hdr.payloadLen);
            processTelemetryFragment(fragment);
            break;
        }

        case CMD_REQUEST_ASA:
        {
            addLog(F("[MC] Received ASA request → sending ACK_ASA"));
            sendASAack(reinterpret_cast<const char *>(buf));
            break;
        }

        case CMD_ACK_ASA:
        {
            String s(reinterpret_cast<const char *>(buf), hdr.payloadLen);
            addLog(String("[MC] ✅ ASA ACK received: ") + s);

            int sf = 0, cr = 0;
            float bw = 0.0f;
            sscanf(s.c_str(), "%d,%d,%f", &sf, &cr, &bw);

            addLog(String("⚙️ Applying new LoRa settings: SF=") + sf +
                   ", CR=" + cr + ", BW=" + String(bw, 1) + "kHz");
            loraComm->applySettings(sf, cr, bw);
            break;
        }
        case CMD_PING:
            addLog(F("[MC] Ping ← Boat"));
            break;
        default:
            // Unhandled packet types …
            break;
        }
    }
    // MissionControl.hpp
    void sendInfoRequest(CommandType what)
    {
        // что именно спрашиваем: T/I/S/F/G/D/K…
        PacketCommand cmd{};
        cmd.packetType = CMD_REQUEST_INFO;
        cmd.packetId = nextPacketId++;
        cmd.payloadLen = 1;
        // первый байт payload — нужный код
        uint8_t code = what;
        memcpy(reinterpret_cast<uint8_t *>(&cmd) + sizeof(PacketBase), &code, 1);
        loraComm->sendPacket(cmd, BOAT_DEVICE_ID);
        addLog("[MC] Sent P(request info=" + String((char)what) + ") to boat");
    }

    // Build and send ASA‐ACK with new speed settings
    void sendASAack(const char *settings)
    {
        PacketAck ack{};
        ack.packetType = CMD_ACK_ASA;
        ack.packetId = nextPacketId++;
        ack.payloadLen = strlen(settings);
        memcpy(reinterpret_cast<uint8_t *>(&ack) + sizeof(PacketBase),
               settings,
               ack.payloadLen);

        loraComm->sendPacket(ack, BOAT_DEVICE_ID);
        addLog(String("[MC] Sent ASA ACK with settings: ") + settings);
    }

    // Assemble telemetry JSON fragments
    void processTelemetryFragment(const String &frag)
    {
        // Format: “[i/N]…chunk…”
        int slashPos = frag.indexOf('/');
        int closePos = frag.indexOf(']');
        int idx = frag.substring(1, slashPos).toInt();
        int total = frag.substring(slashPos + 1, closePos).toInt();
        String chunk = frag.substring(closePos + 1);

        static String buffer;
        static int expected = 0;

        if (idx == 0)
        {
            buffer.clear();
            expected = total;
        }
        buffer += chunk;

        if (idx == expected - 1)
        {
            addLog(F("[MC] 🚀 Telemetry fully received:"));
            addLog(buffer);
            // TODO: deserializeJson(buffer) and handle data…
        }
    }
};
