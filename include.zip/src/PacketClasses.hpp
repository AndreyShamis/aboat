// PacketClasses.hpp
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <type_traits>

// ---------------- CRC16-CCITT (полином 0x1021) ----------------
static uint16_t calcCRC16(const uint8_t* data, size_t len) {
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < len; ++i) {
        crc ^= (uint16_t)data[i] << 8;
        for (int b = 0; b < 8; ++b) {
            if (crc & 0x8000) crc = (crc << 1) ^ 0x1021;
            else            crc <<= 1;
        }
    }
    return crc;
}

// ----------------- Максимальные константы -------------------
static constexpr size_t MAX_ARGS      = 6;    // до 6 аргументов в команде
static constexpr size_t CRC_SIZE      = 2;    // 2 байта CRC
static constexpr size_t HEADER_SIZE   = 4;    // размер PacketBase

// ----------------- Коды команд -----------------------------
enum CommandID : uint8_t {
    CMD_SET_MOTOR         = 1,  // args: [motorIndex, power]
    CMD_SET_RUDDER        = 2,  // args: [angle]
    CMD_START_TELEMETRY   = 3,  // args: []
    CMD_STOP_TELEMETRY    = 4,
    CMD_REQUEST_STATUS    = 5,
    CMD_REQUEST_ENGINE    = 6,
    CMD_HEARTBEAT         = 7,
    // … добавьте свои
};

// ---------------- Пакеты (упакованные без выравнивания) ----------------
#pragma pack(push,1)

// Базовый заголовок любого пакета
class PacketBase {
public:
    uint8_t  packetType;   // 'C','T','I','S','A','G','H'=Heartbeat
    uint8_t  packetId;     // сквозной номер 0…255
    uint16_t payloadLen;   // длина тела (без заголовка и CRC)
};
static_assert(sizeof(PacketBase) == HEADER_SIZE, "PacketBase size");

// Пакет-команда: cmdId + произв.число аргументов
class PacketCommand : public PacketBase {
public:
    uint8_t  cmdId;                // из CommandID
    uint8_t  argCount;             // реально используемых args
    int8_t   args[MAX_ARGS];       // каждый –128…127
};
static_assert(sizeof(PacketCommand) == HEADER_SIZE + 2 + MAX_ARGS,
              "PacketCommand size");

// Телеметрия: пример – скорость, курс, уровень батареи
class PacketTelemetry : public PacketBase {
public:
    uint8_t  speed;      // 0–255
    uint8_t  course;     // 0–179 (0–359°/2)
    uint8_t  battLevel;  // 0–100%
};
static_assert(sizeof(PacketTelemetry) == HEADER_SIZE + 3,
              "PacketTelemetry size");

// Инфо о двигателе: RPM и температура
class PacketInfoEngine : public PacketBase {
public:
    int16_t  rpm;        // 0–20000
    int8_t   temp;       // –40…85
};
static_assert(sizeof(PacketInfoEngine) == HEADER_SIZE + 3,
              "PacketInfoEngine size");

// Статус: битовые флаги
class PacketStatus : public PacketBase {
public:
    uint8_t  statusFlags; // бит0=OK,1=LowBatt,2=SensorErr…
};
static_assert(sizeof(PacketStatus) == HEADER_SIZE + 1,
              "PacketStatus size");

// Подтверждение (ACK)
class PacketAck : public PacketBase {
public:
    uint8_t  ackedId;    // packetId того, что подтверждаем
    uint8_t  result;     // 0=OK,≠0=код ошибки
};
static_assert(sizeof(PacketAck) == HEADER_SIZE + 2,
              "PacketAck size");

// Конфиг-пакет (изменение параметра)
class PacketConfig : public PacketBase {
public:
    uint8_t  paramId;
    int8_t   value;
};
static_assert(sizeof(PacketConfig) == HEADER_SIZE + 2,
              "PacketConfig size");

// Навигация: GPS
class PacketNav : public PacketBase {
public:
    int32_t  lat;   // 1e-7°
    int32_t  lon;   // 1e-7°
    uint16_t hdop;  // HDOP×100
};
static_assert(sizeof(PacketNav) == HEADER_SIZE + 10,
              "PacketNav size");

// Heartbeat: просто счётчик
class PacketHeartbeat : public PacketBase {
public:
    uint32_t count; // произвольный счётчик
};
static_assert(sizeof(PacketHeartbeat) == HEADER_SIZE + 4,
              "PacketHeartbeat size");

#pragma pack(pop)

// // Все пакеты — trivially copyable => безопасны для memcpy
// static_assert(std::is_trivially_copyable<PacketBase>::value,       "");
// static_assert(std::is_standard_layout<PacketBase>::value,          "");
// static_assert(std::is_trivially_copyable<PacketCommand>::value,    "");
// static_assert(std::is_standard_layout<PacketCommand>::value,       "");
// // … и т.д. для остальных

// ----------------- Сериализация / Десериализация -----------------
template<typename T>
struct PacketSerializer {
    // Копируем объект + дописываем CRC16
    static size_t serialize(const T& pkt, uint8_t* buf) {
        size_t pktSize = sizeof(T);
        memcpy(buf, &pkt, pktSize);
        uint16_t crc = calcCRC16(buf, pktSize);
        buf[pktSize + 0] = uint8_t(crc >> 8);
        buf[pktSize + 1] = uint8_t(crc & 0xFF);
        return pktSize + CRC_SIZE;
    }
    // Проверяем CRC и возвращаем true, если корректен
    static bool validate(const uint8_t* buf, size_t totalLen) {
        if (totalLen < CRC_SIZE) return false;
        size_t pktSize = totalLen - CRC_SIZE;
        uint16_t recvCrc = (uint16_t(buf[pktSize]) << 8) | buf[pktSize+1];
        return recvCrc == calcCRC16(buf, pktSize);
    }
};

// ----------------- Обработчик пакетов -----------------
class PacketHandler {
public:
    // Интерфейс должен быть реализован в вашем коде:
    static void onCommand(const PacketCommand&);
    static void onTelemetry(const PacketTelemetry&);
    static void onInfoEngine(const PacketInfoEngine&);
    static void onStatus(const PacketStatus&);
    static void onAck(const PacketAck&);
    static void onConfig(const PacketConfig&);
    static void onNav(const PacketNav&);
    static void onHeartbeat(const PacketHeartbeat&);
    
    // Автоматический диспетчер по типу
    static void handle(const uint8_t* buf, size_t totalLen) {
        if (!PacketSerializer<PacketBase>::validate(buf, totalLen)) {
            // CRC не прошёл
            return;
        }
        const PacketBase* base = reinterpret_cast<const PacketBase*>(buf);
        switch (base->packetType) {
            case 'C': onCommand     (*(const PacketCommand*)buf);      break;
            case 'T': onTelemetry   (*(const PacketTelemetry*)buf);    break;
            case 'I': onInfoEngine  (*(const PacketInfoEngine*)buf);   break;
            case 'S': onStatus      (*(const PacketStatus*)buf);       break;
            case 'A': onAck         (*(const PacketAck*)buf);          break;
            case 'F': onConfig      (*(const PacketConfig*)buf);       break;
            case 'G': onNav         (*(const PacketNav*)buf);          break;
            case 'H': onHeartbeat   (*(const PacketHeartbeat*)buf);    break;
            default: /* неизвестный */                                  break;
        }
    }
};

// Пример клиента (пульт управления)

// // Controller.ino
// #include <Arduino.h>
// #include "PacketClasses.h"

// #define TRANSPORT Serial1  // допустим, LoRa-порт

// uint8_t nextPacketId = 0;

// void setup() {
//   Serial.begin(115200);
//   TRANSPORT.begin(9600);
// }

// void loop() {
//   // Пример: отправить команду SET_MOTOR (motorIndex=0, power=80)
//   PacketCommand cmd{};
//   cmd.packetType = 'C';
//   cmd.packetId   = nextPacketId++;
//   cmd.payloadLen = sizeof(PacketCommand) - HEADER_SIZE;
//   cmd.cmdId      = CMD_SET_MOTOR;
//   cmd.argCount   = 2;
//   cmd.args[0]    = 0;    // мотор 0
//   cmd.args[1]    = 80;   // 80%

//   uint8_t buf[sizeof(cmd) + CRC_SIZE];
//   size_t len = PacketSerializer<PacketCommand>::serialize(cmd, buf);
//   TRANSPORT.write(buf, len);

//   delay(500);  // полсекунды между пакетами
// }




//Пример сервера (лодка)
// Boat.ino
// #include <Arduino.h>
// #include "PacketClasses.h"

// #define TRANSPORT Serial1  // тот же порт LoRa

// void setup() {
//   Serial.begin(115200);
//   TRANSPORT.begin(9600);
// }

// // Реализуем только необходимые колбэки
// void PacketHandler::onCommand(const PacketCommand& pc) {
//   Serial.printf("[BOAT] CMD %u args=%u:", pc.cmdId, pc.argCount);
//   for (int i = 0; i < pc.argCount; ++i) {
//     Serial.printf(" %d", pc.args[i]);
//   }
//   Serial.println();
//   // тут — ваша логика исполнения
// }

// void loop() {
//   // Ждём минимум заголовок + CRC
//   if (TRANSPORT.available() < HEADER_SIZE + CRC_SIZE) return;

//   // Смотрим на заголовок, узнаём payloadLen
//   PacketBase hdr;
//   TRANSPORT.peekBytes((uint8_t*)&hdr, sizeof(hdr));
//   size_t totalLen = HEADER_SIZE + hdr.payloadLen + CRC_SIZE;

//   if (TRANSPORT.available() < totalLen) return;
  
//   // Читаем весь пакет
//   uint8_t buf[64];
//   TRANSPORT.readBytes(buf, totalLen);
  
//   // Передаём в диспетчер
//   PacketHandler::handle(buf, totalLen);
// }
