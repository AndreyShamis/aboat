// PacketTransport.hpp
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "PacketClasses.hpp"   // содержит calcCRC16 и классы Packet*

static constexpr size_t MAX_LORA_PAYLOAD = 40;

#pragma pack(push,1)
struct LoRaPacket {
    uint8_t  senderId;
    uint8_t  receiverId;
    uint8_t  packetType;
    uint16_t packetId;
    uint16_t payloadLen;
    uint8_t  payload[MAX_LORA_PAYLOAD];
    uint16_t crc;
};
static_assert(sizeof(LoRaPacket) <= 64, "LoRaPacket слишком большой!");
#pragma pack(pop)

// Упаковка любого Packet* в LoRaPacket
template<typename P>
size_t packIntoLoRa(uint8_t senderId,
                    uint8_t receiverId,
                    const P &pkt,
                    LoRaPacket &out)
{
    // Копируем метаданные
    out.senderId    = senderId;
    out.receiverId  = receiverId;
    out.packetType  = pkt.packetType;
    out.packetId    = pkt.packetId;
    out.payloadLen  = pkt.payloadLen;
    // Копируем тело (только payload)
    memcpy(out.payload,
           reinterpret_cast<const uint8_t*>(&pkt) + sizeof(PacketBase),
           pkt.payloadLen);
    // Считаем CRC16 по всему пакету до конца payload
    size_t crcLen = offsetof(LoRaPacket, payload) + pkt.payloadLen;
    out.crc = calcCRC16(reinterpret_cast<const uint8_t*>(&out), crcLen);
    return crcLen + sizeof(out.crc);
}

// Распаковка LoRaPacket обратно в PacketBase + payloadBuf
inline bool unpackLoRa(const LoRaPacket &in,
                      uint8_t &outSender,
                      uint8_t &outReceiver,
                      PacketBase &hdr,
                      uint8_t *payloadBuf)
{
    // Проверяем CRC
    size_t crcLen = offsetof(LoRaPacket, payload) + in.payloadLen;
    if (calcCRC16(reinterpret_cast<const uint8_t*>(&in), crcLen) != in.crc) {
        return false;
    }
    // Извлекаем метаданные
    outSender         = in.senderId;
    outReceiver       = in.receiverId;
    hdr.packetType    = in.packetType;
    hdr.packetId      = in.packetId;
    hdr.payloadLen    = in.payloadLen;
    // Копируем payload
    memcpy(payloadBuf, in.payload, in.payloadLen);
    return true;
}
